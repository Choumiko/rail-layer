require "defines"
godmode = false
removeStone = true

polePlacement = {
    side = 1, -- 1 for right side of travel direction, -1 for left
    distance = 1, -- distance from track in tiles
    data = {},
    dir = {}
}

signalPlacement = {
    distance = 15, -- signal distance in straight rails (roughly)
}